@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo BEBENINE AI STUDIO dependency install failed.
  pause
  exit /b 1
)
python app.py
pause
