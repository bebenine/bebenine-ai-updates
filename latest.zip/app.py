import os, base64, uuid
from pathlib import Path
from flask import Flask, render_template, request, send_from_directory, jsonify
from openai import OpenAI

BASE = Path(__file__).parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 50 * 1024 * 1024

MASTER = """
You are creating a commercial children's fashion catalog image for BEBENINE.
The uploaded product photos are authoritative references. Preserve the actual garment construction.
Do not redesign, beautify, simplify, add, remove, or reinterpret product details.
Match stripe width, stripe spacing, color placement, button count and position, hood construction,
pom-pom, seams, sleeve length, elastic/bubble hem, silhouette, front and back construction.
For a BACK pose, use the uploaded back-view product image as the primary authority.
For a FRONT pose, use the uploaded front-view product image as the primary authority.
Keep realistic fabric drape and child-safe, non-sexual commercial styling. Hats, accessories, shoes, socks and hairstyles are styling additions only and must never alter, cover up, replace, or redesign authoritative garment details.
If a requested body measurement cannot be represented precisely, make only a plausible visual approximation.
"""

def build_prompt(form, pose_override=None):
    model_type = form.get("model_type", "한국 여아")
    height = form.get("height", "80")
    weight = form.get("weight", "10")
    body = form.get("body", "통통")
    pose = pose_override or form.get("pose", "정면")
    hood = form.get("hood", "착용")
    styling = form.get("styling", "크림 레깅스와 양말")
    background = form.get("background", "밝은 아이보리 스튜디오")
    product = form.get("product_name", "BEBENINE product")
    return MASTER + f"""
Product: {product}
Virtual model: {model_type}
Approximate child height: {height} cm
Approximate child weight: {weight} kg
Body build: {body}
Pose/view: {pose}
Hood: {hood}
Styling: {styling}
Background: {background}
Create one premium Korean children's fashion e-commerce image. Full body visible.
No text, logo overlays, collage, watermark, extra garments, or product redesign.
"""

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    api_key = os.getenv("OPENAI_API_KEY") or request.form.get("api_key")
    if not api_key:
        return jsonify({"error":"OpenAI API 키를 입력하세요."}), 400

    files = request.files.getlist("references")
    files = [f for f in files if f and f.filename]
    if not files:
        return jsonify({"error":"상품 참조사진을 1장 이상 업로드하세요."}), 400

    saved = []
    handles = []
    try:
        for f in files[:16]:
            ext = Path(f.filename).suffix.lower() or ".jpg"
            p = UPLOADS / f"{uuid.uuid4().hex}{ext}"
            f.save(p)
            saved.append(p)
            handles.append(open(p, "rb"))

        client = OpenAI(api_key=api_key)
        poses = request.form.getlist("poses") or [request.form.get("pose", "정면")]
        count = int(request.form.get("count", "1"))
        urls = []
        for pose in poses:
            # Re-open references for each selected view because the SDK may consume file handles.
            for h in handles:
                try: h.close()
                except: pass
            handles = [open(p, "rb") for p in saved]
            result = client.images.edit(
                model="gpt-image-2.5-sunburst",
                image=handles,
                prompt=build_prompt(request.form, pose_override=pose),
                quality=request.form.get("quality", "high"),
                size=request.form.get("size", "1024x1536"),
                output_format="jpeg",
                n=count
            )
            for item in result.data:
                raw = base64.b64decode(item.b64_json)
                name = f"{pose}_{uuid.uuid4().hex}.jpg"
                (OUTPUTS/name).write_bytes(raw)
                urls.append("/outputs/" + name)
        return jsonify({"images": urls})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        for h in handles:
            try: h.close()
            except: pass


@app.route("/compare", methods=["POST"])
def compare():
    api_key = os.getenv("OPENAI_API_KEY") or request.form.get("api_key")
    if not api_key:
        return jsonify({"error":"OpenAI API 키를 입력하세요."}), 400

    files = request.files.getlist("references")
    files = [f for f in files if f and f.filename]
    if not files:
        return jsonify({"error":"상품 참조사진을 1장 이상 업로드하세요."}), 400

    saved, handles = [], []
    try:
        for f in files[:16]:
            ext = Path(f.filename).suffix.lower() or ".jpg"
            p = UPLOADS / f"{uuid.uuid4().hex}{ext}"
            f.save(p)
            saved.append(p)

        client = OpenAI(api_key=api_key)
        results = []
        for quality in ["medium", "high", "xhigh", "max"]:
            handles = [open(p, "rb") for p in saved]
            try:
                result = client.images.edit(
                    model="gpt-image-2.5-sunburst",
                    image=handles,
                    prompt=build_prompt(request.form),
                    quality=quality,
                    size=request.form.get("size", "1024x1536"),
                    output_format="jpeg",
                    n=1
                )
                raw = base64.b64decode(result.data[0].b64_json)
                name = f"{quality}_{uuid.uuid4().hex}.jpg"
                (OUTPUTS/name).write_bytes(raw)
                usage = getattr(result, "usage", None)
                usage_data = usage.model_dump() if hasattr(usage, "model_dump") else (usage if isinstance(usage, dict) else None)
                results.append({"quality":quality, "url":"/outputs/"+name, "usage":usage_data})
            finally:
                for h in handles:
                    try: h.close()
                    except: pass
                handles = []
        return jsonify({"images": results})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/outputs/<path:name>")
def outputs(name):
    return send_from_directory(OUTPUTS, name)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860, debug=False)
