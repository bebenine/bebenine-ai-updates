import os
import json, base64, uuid
from pathlib import Path
from flask import Flask, render_template, request, send_from_directory, jsonify
from openai import OpenAI

BASE = Path(__file__).parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = Flask(__name__)

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")

def load_saved_api_key():
    try:
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return (json.load(f).get("openai_api_key") or "").strip()
    except Exception:
        pass
    return (load_saved_api_key() or "").strip()

def save_api_key(key):
    data = {}
    try:
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
    except Exception:
        data = {}
    data["openai_api_key"] = key.strip()
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

app.config["MAX_CONTENT_LENGTH"] = 16 * 50 * 1024 * 1024

MASTER = """
You are creating a commercial children's fashion catalog image for BEBENINE.
The uploaded product photos are authoritative references. Preserve the actual garment construction.
Do not redesign, beautify, simplify, add, remove, or reinterpret product details.
Match stripe width, stripe spacing, color placement, button count and position, hood construction,
pom-pom, seams, sleeve length, elastic/bubble hem, silhouette, front and back construction.
For a BACK pose, use the uploaded back-view product image as the primary authority.
For a FRONT pose, use the uploaded front-view product image as the primary authority.
Keep realistic fabric drape and child-safe, non-sexual commercial styling. Hats, accessories, shoes, socks and hairstyles are styling additions only and must never alter, cover up, replace, or redesign authoritative garment details.
If a requested body measurement cannot be represented precisely, make only a plausible visual approximation.
"""

def build_prompt(form, overrides=None):
    overrides = overrides or {}
    model_type = overrides.get("model_type", form.get("model_type", "한국 여아"))
    height = overrides.get("height", form.get("height", "80"))
    weight = overrides.get("weight", form.get("weight", "10"))
    body = overrides.get("body", form.get("body", "통통"))
    pose = overrides.get("pose", form.get("pose", "정면"))
    hood = overrides.get("hood", form.get("hood", "착용"))
    styling = form.get("styling", "크림 레깅스와 양말")
    hat = overrides.get("hat", form.get("hat", "없음"))
    hairstyle = overrides.get("hairstyle", form.get("hairstyle", "자연스러운 머리"))
    accessories = form.get("accessories", "없음")
    background = overrides.get("background", form.get("background", "밝은 아이보리 스튜디오"))
    product = form.get("product_name", "BEBENINE product")
    return MASTER + f"""
Product: {product}
Virtual model: {model_type}
Approximate child height: {height} cm
Approximate child weight: {weight} kg
Body build: {body}
Pose/view: {pose}
Hood: {hood}
Styling: {styling}
Hat: {hat}
Hairstyle: {hairstyle}
Accessories: {accessories}
Background: {background}
Create one premium Korean children's fashion e-commerce image. Full body visible.
No text, logo overlays, collage, watermark, extra garments, or product redesign.
"""


@app.route("/api-key-status", methods=["GET"])
def api_key_status():
    key = load_saved_api_key()
    return jsonify({"saved": bool(key), "masked": ("sk-••••••••" + key[-4:]) if len(key) >= 4 else ""})

@app.route("/save-api-key", methods=["POST"])
def save_api_key_route():
    key = (request.form.get("api_key") or "").strip()
    if not key:
        return jsonify({"ok": False, "error": "API 키를 입력하세요."}), 400
    save_api_key(key)
    return jsonify({"ok": True})

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    import itertools
    api_key = load_saved_api_key() or request.form.get("api_key")
    if not api_key:
        return jsonify({"error":"OpenAI API 키를 입력하세요."}), 400
    files = [f for f in request.files.getlist("references") if f and f.filename]
    if not files:
        return jsonify({"error":"상품 참조사진을 1장 이상 업로드하세요."}), 400

    saved=[]; handles=[]
    try:
        for f in files[:16]:
            ext=Path(f.filename).suffix.lower() or ".jpg"
            p=UPLOADS/f"{uuid.uuid4().hex}{ext}"; f.save(p); saved.append(p)

        def vals(plural, fallback):
            v=request.form.getlist(plural)
            return v if v else [fallback]
        def csvvals(name, fallback):
            raw=request.form.get(name, fallback)
            v=[x.strip() for x in raw.split(",") if x.strip()]
            return v or [fallback]

        dimensions = {
          "model_type": vals("model_types","한국 여아"),
          "body": vals("bodys","통통"),
          "height": csvvals("height","80"),
          "weight": csvvals("weight","10"),
          "pose": vals("poses","정면"),
          "hood": vals("hoods","착용"),
          "hat": vals("hats","없음"),
          "hairstyle": vals("hairstyles","자연스러운 머리"),
          "background": vals("backgrounds","밝은 아이보리 스튜디오"),
        }
        qualities=vals("qualitys","high")
        counts=[int(x) for x in vals("counts","1")]
        keys=list(dimensions)
        combos=[dict(zip(keys,x)) for x in itertools.product(*(dimensions[k] for k in keys))]
        total=sum(counts)*len(qualities)*len(combos)
        if total > 40:
            return jsonify({"error":f"선택 조합이 총 {total}장입니다. 한 번에 최대 40장까지 생성하도록 선택 수를 줄여주세요."}),400

        client=OpenAI(api_key=api_key); urls=[]
        for combo in combos:
          for quality in qualities:
            for count in counts:
              handles=[open(p,"rb") for p in saved]
              try:
                result=client.images.edit(
                  model="gpt-image-2.5-sunburst", image=handles,
                  prompt=build_prompt(request.form, combo),
                  quality=quality, size=request.form.get("size","1024x1536"),
                  output_format="jpeg", n=count)
              finally:
                for h in handles:
                    try:h.close()
                    except:pass
                handles=[]
              tag="_".join(str(combo[k]) for k in ["model_type","body","pose","hood"])
              for item in result.data:
                raw=base64.b64decode(item.b64_json)
                name=f"{tag}_{quality}_{uuid.uuid4().hex}.jpg"
                (OUTPUTS/name).write_bytes(raw); urls.append("/outputs/"+name)
        return jsonify({"images":urls,"count":len(urls)})
    except Exception as e:
        return jsonify({"error":str(e)}),500
    finally:
        for h in handles:
            try:h.close()
            except:pass


@app.route("/compare", methods=["POST"])
def compare():
    api_key = load_saved_api_key() or request.form.get("api_key")
    if not api_key:
        return jsonify({"error":"OpenAI API 키를 입력하세요."}), 400

    files = request.files.getlist("references")
    files = [f for f in files if f and f.filename]
    if not files:
        return jsonify({"error":"상품 참조사진을 1장 이상 업로드하세요."}), 400

    saved, handles = [], []
    try:
        for f in files[:16]:
            ext = Path(f.filename).suffix.lower() or ".jpg"
            p = UPLOADS / f"{uuid.uuid4().hex}{ext}"
            f.save(p)
            saved.append(p)

        client = OpenAI(api_key=api_key)
        results = []
        for quality in ["medium", "high", "xhigh", "max"]:
            handles = [open(p, "rb") for p in saved]
            try:
                result = client.images.edit(
                    model="gpt-image-2.5-sunburst",
                    image=handles,
                    prompt=build_prompt(request.form, {"pose": (request.form.getlist("poses") or ["정면"])[0]}),
                    quality=quality,
                    size=request.form.get("size", "1024x1536"),
                    output_format="jpeg",
                    n=1
                )
                raw = base64.b64decode(result.data[0].b64_json)
                name = f"{quality}_{uuid.uuid4().hex}.jpg"
                (OUTPUTS/name).write_bytes(raw)
                usage = getattr(result, "usage", None)
                usage_data = usage.model_dump() if hasattr(usage, "model_dump") else (usage if isinstance(usage, dict) else None)
                results.append({"quality":quality, "url":"/outputs/"+name, "usage":usage_data})
            finally:
                for h in handles:
                    try: h.close()
                    except: pass
                handles = []
        return jsonify({"images": results})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/outputs/<path:name>")
def outputs(name):
    return send_from_directory(OUTPUTS, name)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860, debug=False)
